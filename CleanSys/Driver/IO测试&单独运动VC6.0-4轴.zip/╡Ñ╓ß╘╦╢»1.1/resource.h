//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by iSingleAxisMotion.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_ISINGLEAXISMOTION_DIALOG    102
#define IDR_MAINFRAME                   128
#define IDC_STATIC_STATUS               1001
#define IDC_STATIC_POS                  1002
#define IDC_CHECK_LOGIC                 1003
#define IDC_RADIO_ACTIONST              1004
#define IDC_RADIO_CMOVE                 1005
#define IDC_EDIT_PULSE                  1006
#define IDC_EDTSPEED                    1007
#define IDC_EDTSPEEDACC                 1008
#define IDC_EDTSPEEDEC                  1009
#define IDC_RADIO_X_AXS                 1010
#define IDC_RADIO_Y_AXS                 1011
#define IDC_RADIO_Z_AXS                 1012
#define IDC_RADIO_W_AXS                 1013
#define IDC_BTNEXC                      1015
#define IDC_BTNSTOP                     1016
#define IDC_BTNZERO                     1017
#define IDC_BTNEMGSTOP                  1018
#define IDC_BTNRETZERO                  1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
